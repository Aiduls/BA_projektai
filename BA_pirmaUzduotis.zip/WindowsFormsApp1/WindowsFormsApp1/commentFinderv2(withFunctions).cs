﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace WindowsFormsApp1
{
    public partial class CommentFinder : Form
    {
        public CommentFinder()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            string FolderPath = textBox1.Text; // Variable with the path to folder is set
            // C:\Users\Aidas\Desktop\Mokslai\IT\ReadmeBA-master\ReadmeBA-master\ReadmeBA

            string commentFilePath = FolderPath + "\\comments.txt";
            File.Delete(commentFilePath); // deletes the previous file if such was created earlier
            string[] fileNames = Directory.GetFiles(FolderPath, "*", SearchOption.AllDirectories); // list of all files within the folder and its subfolders is set
            GettingComments(fileNames, FolderPath, commentFilePath);

        }

        string endCommentSA = "*/";
        string endCommentHTML = "-->";

        private void GettingComments(string[] fileNames, string folderPath, string commentFilePath)
        {
            string commentDoubleSlash = "//"; /* types of comments */
            string commentTripleSlash = "///";
            string commentSlashAsterisk = "/*"; bool IsSACommentActive = false; // SA - Slash Asterisk comment
            string commentHTML = "<!--"; bool IsHTMLCommentActive = false;
            

            string comment;
            int noOfComments = 0; // index of comments
            string filename;
            int stringCount;
            bool isStringActive = false;
            string line;
            for (int i = 0; i < fileNames.Length; i++)  // START OF FILE -- a loop going through each file
            {
                filename = Path.GetFileName(fileNames[i]);
                noOfComments = 0; // comment index is nullified each iteration

                using (StreamWriter file =
                    new StreamWriter(commentFilePath, true))
                {
                    file.WriteLine("=========== " + filename + " ===========",true); // file name is written each iteration
                    file.Close();
                }
                

                string fileName = fileNames[i];     // file path+name is set
                string[] lines = File.ReadAllLines(fileName); // all lines from file are got

                /*foreach (string line in lines) // START OF LINE -- checking every line */
                for (int k=0; k<lines.Length; k++)
                {
                    line = lines[k];
                    // if statement to check if line contains any kind of comment
                    if(line.Contains(commentDoubleSlash) || line.Contains(commentTripleSlash) || line.Contains(commentSlashAsterisk)|| line.Contains(commentHTML) || IsSACommentActive || IsHTMLCommentActive)
                    {
                        if (isStringActive)
                        {
                            line = line.Remove(0, '"');   // unnecesary part removed 
                            isStringActive = false;
                        }
                        // If statements to further check what kind of comment it contains
                        if ((line.Contains(commentDoubleSlash) || line.Contains(commentTripleSlash)) && !IsSACommentActive && !IsHTMLCommentActive)
                        {
                            comment = getComment(line, commentDoubleSlash, "");   // comment is got
                            noOfComments++;                                     // index of comment is increased
                            WriteInFile(noOfComments, comment, commentFilePath);// comment and its index is written into the file
                        }
                        else if ((line.Contains(commentSlashAsterisk) || IsSACommentActive) && !IsHTMLCommentActive)
                        {
                            if (IsSACommentActive) // checks if the SA comment is ongoing
                            {
                                if (line.Contains(endCommentSA)) // check is the ongoing comment ends on this line
                                {
                                    comment = getComment(line, "", endCommentSA);
                                    WriteInFile(-1, comment, commentFilePath);
                                    IsSACommentActive = false;

                                }
                                else                            // if not, whole line gets written as comment
                                {
                                    comment = line;
                                    WriteInFile(-1, comment, commentFilePath);
                                }

                            }
                            else
                            {
                                if (line.Contains(endCommentSA)) // checks if the SA comment starts AND ENDS on this line
                                {
                                    comment = getComment(line, commentSlashAsterisk, endCommentSA);
                                    noOfComments++;
                                    WriteInFile(noOfComments, comment, commentFilePath);
                                    IsSACommentActive = false;
                                }
                                else        // comment only starts, but doesn't end on this line
                                {
                                    comment = getComment(line, commentSlashAsterisk, "");
                                    noOfComments++;
                                    WriteInFile(noOfComments, comment, commentFilePath);
                                    IsSACommentActive = true;
                                }
                            }
                        }
                        else if ((line.Contains(commentHTML) || IsHTMLCommentActive) && !IsSACommentActive)
                        {
                            if (IsHTMLCommentActive) // checks if the HTML comment is ongoing
                            {
                                if (line.Contains(endCommentHTML)) // checks if it ends on this line
                                {
                                    comment = getComment(line, "", endCommentHTML);
                                    WriteInFile(-1, comment, commentFilePath);
                                    IsSACommentActive = false;
                                }
                                else
                                {
                                    comment = line; // if the whole line is a comment
                                    WriteInFile(-1, comment, commentFilePath);
                                }

                            }
                            else
                            {
                                if (line.Contains(endCommentHTML)) // if it starts and ends on this line
                                {
                                    comment = getComment(line, commentHTML, endCommentHTML);
                                    noOfComments++;
                                    WriteInFile(noOfComments, comment, commentFilePath);
                                    IsSACommentActive = false;
                                }
                                else // if it only starts on this line
                                {
                                    comment = getComment(line, commentHTML, "");
                                    noOfComments++;
                                    WriteInFile(noOfComments, comment, commentFilePath);
                                    IsSACommentActive = true;
                                }
                            }
                        }
                    }
                    else // line doesn't contain any comments
                    {
                        stringCount = line.Count(x => x == '"'); 
                        if (stringCount % 2 == 1)   // checking if line starts a string 
                        {
                            isStringActive = true;
                        }
                        else isStringActive = false;
                    }
                } // END OF LINE LOOP   
            }   // end of file
        }

        private string getComment(string line, string commentStart, string commentEnd)
        {
            int commentStartIndex;
            if (commentStart == "") // if null is sent, this is an ongoing comment - index set at 0
            {
                commentStartIndex = 0;
            }
            else                    //otherwise, index is set at the start of comment
            {
                commentStartIndex = line.IndexOf(commentStart);
            }
            line = line.Remove(0, commentStartIndex);   // unnecesary part removed 
            commentStartIndex = line.IndexOf(commentStart); // start index rewritten with renowned line
            int commentEndIndex;
            
            if (commentEnd == endCommentSA) // if the comment end is sent, its character count is added
            {
                commentEndIndex = line.IndexOf(commentEnd)+2;
            }
            else if (commentEnd == endCommentHTML) 
            {
                commentEndIndex = line.IndexOf(commentEnd) + 3;
            }
            else // if null is sent, the comment lasts for the whole line - index is set at the length of line
            {
                commentEndIndex = line.Length;
            }
            string comment = line.Substring(commentStartIndex, commentEndIndex); // comment is set

            return comment; // comment is returned
        }

        private void WriteInFile(int index, string line, string commentFilePath)
        {
            using (StreamWriter file =
                    new StreamWriter(commentFilePath, true))
            {
                if (index == -1) // if the comment is ongoing - no index needed
                {
                    file.WriteLine(line);
                    file.Close();
                }
                else
                {
                    file.WriteLine(index + ". " + line); // if the comment starts - index is written along with the comment
                    file.Close();
                }

            }
        }
    }
}
