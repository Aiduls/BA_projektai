﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Linq;

namespace WindowsFormsApp1
{
    public partial class CommentFinder : Form
    {
        public CommentFinder()
        {
            InitializeComponent();
        }

        string commentFilePath;

        private void button_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderFinder = new FolderBrowserDialog();
            folderFinder.Description = "Please choose a folder containing files with comments";
            if (folderFinder.ShowDialog() == DialogResult.OK)
            {
                label2.Visible = true;
                string FolderPath = folderFinder.SelectedPath; // Variable with the path to folder is set
                

                commentFilePath = FolderPath + "\\comments.txt";
                File.Delete(commentFilePath); // deletes the previous file if such was created earlier
                string[] fileNames = Directory.GetFiles(FolderPath, "*", SearchOption.AllDirectories); // list of all files within the folder and its subfolders is set
                GettingComments(fileNames, FolderPath);
            }
            else
            {
                MessageBox.Show("Please choose a folder from which the comments should be extracted","Important Note", MessageBoxButtons.OK,MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            

        }

        string endCommentSA = "*/";
        string endCommentHTML = "-->";
        int commentIndex;
        string finalComment;


        private void GettingComments(string[] fileNames, string folderPath)
        {
            string commentDoubleSlash = "//"; /* types of comments */
            string commentTripleSlash = "///";
            string commentSlashAsterisk = "/*"; bool IsSACommentActive = false; // SA - Slash Asterisk comment
            string commentHTML = "<!--"; bool IsHTMLCommentActive = false;
            

            string comment;
            int noOfComments = 0; // index of comments
            string filename;
            int stringCount;
            bool isStringActive = false;
            string line;

            bool isDoubleSlashActive; 
            bool wasSAWritten; // are used to check for 2 comment types within the same line

            string htmlCheck;

            for (int i = 0; i < fileNames.Length; i++)  // START OF FILE -- a loop going through each file
            {
                filename = Path.GetFileName(fileNames[i]);
                noOfComments = 0; // comment index is nullified each iteration

                using (StreamWriter file =
                    new StreamWriter(commentFilePath, true))
                {
                    file.WriteLine("=========== " + filename + " ===========",true); // file name is written each iteration
                    file.Close();
                }
                

                string fullFileName = fileNames[i];     // file path+name is set
                string[] lines = File.ReadAllLines(fullFileName); // all lines from file are got

                for (int k=0; k<lines.Length; k++) // Iteration through file lines is started
                {
                    line = lines[k];

                    isDoubleSlashActive = false; // comments are false by default, unless it's activated
                    wasSAWritten = false;

                    // if statement to check if line contains any kind of comment
                    if(line.Contains(commentDoubleSlash) || line.Contains(commentTripleSlash) || line.Contains(commentSlashAsterisk)|| line.Contains(commentHTML) || IsSACommentActive || IsHTMLCommentActive)
                    {
                        if (isStringActive) // checks if current part of line is within a string
                        {
                            if (line.Contains('"'))
                            {
                                line = line.Remove(0, '"');   // if string ends on this line, unnecesary part removed 
                                isStringActive = false;
                            }
                            else isStringActive = true;

                        }
                        // If statements to further check what kind of comment it contains

                        // ---
                        // DOUBLE SLASH COMMENT SEARCH
                        // ---
                        StringSearch:
                        if ((line.Contains(commentDoubleSlash) || line.Contains(commentTripleSlash)) && !IsSACommentActive && !IsHTMLCommentActive)
                        {
                            
                            if (isInString(line, commentDoubleSlash)) // if true - the comment mark is in a string, therefore it's not a comment
                            {
                                // it's not a comment
                                if (line.Contains('"') && line.Length > 1)
                                {
                                    line = line.Remove(0, line.IndexOf('"') + 1); // these two lines remove the string and continue to check the line
                                    line = line.Remove(0, line.IndexOf('"') + 1); // for more comments after the removed string
                                    goto StringSearch;
                                }
                            }
                            else
                            {
                                comment = getComment(line, commentDoubleSlash, "");   // comment is got
                                finalComment = comment;
                                commentIndex = comment.IndexOf(commentDoubleSlash); // Comment index is set to later check which comment starts first
                                isDoubleSlashActive = true;
                            }
                        }

                        // ---
                        // SLASH ASTERISK COMMENT SEARCH
                        // ---

                        if ((line.Contains(commentSlashAsterisk) || IsSACommentActive) && !IsHTMLCommentActive)
                        {
                            if (IsSACommentActive) // checks if the SA comment is ongoing
                            {
                                if (line.Contains(endCommentSA)) // check is the ongoing comment ends on this line
                                {
                                    comment = getComment(line, "", endCommentSA);
                                    WriteInFile(-1, comment);
                                    IsSACommentActive = false;

                                }
                                else                            // if not, whole line gets written as comment
                                {
                                    comment = line;
                                    WriteInFile(-1, comment);
                                }

                            }
                            else
                            {
                                if (line.Contains(endCommentSA)) // checks if the SA comment starts AND ENDS on this line
                                {
                                    if (isInString(line, commentSlashAsterisk)) // if true - the comment mark is in a string, therefore it's not a comment
                                    {
                                        line = line.Remove(0, line.IndexOf('"') + 1); // removes the string and continues checking line
                                        line = line.Remove(0, line.IndexOf('"') + 1);
                                        goto StringSearch;
                                    }

                                    if (isDoubleSlashActive) // if this is active, 2 types of comments have been caught on this line
                                    {
                                        if (commentIndex < line.IndexOf(commentSlashAsterisk)) // if '//' type comment starts first
                                        {
                                            noOfComments++;
                                            WriteInFile(noOfComments, finalComment);
                                        }
                                        else                // if '/*' type comment starts first
                                        {
                                            comment = getComment(line, commentSlashAsterisk, endCommentSA);
                                            noOfComments++;
                                            WriteInFile(noOfComments, comment);
                                            IsSACommentActive = false;
                                            wasSAWritten = true;
                                        }
                                    }
                                    else // is '/*' type comment starts first
                                    {
                                        comment = getComment(line, commentSlashAsterisk, endCommentSA);
                                        noOfComments++;
                                        WriteInFile(noOfComments, comment);
                                        IsSACommentActive = false;
                                    }
                                }
                                else        // comment only starts, but doesn't end on this line
                                {
                                    if (isDoubleSlashActive)
                                    {
                                        if (commentIndex < line.IndexOf(commentSlashAsterisk))
                                        {
                                            noOfComments++;
                                            WriteInFile(noOfComments, finalComment);
                                        }
                                        else
                                        {
                                            comment = getComment(line, commentSlashAsterisk, "");
                                            noOfComments++;
                                            WriteInFile(noOfComments, comment);
                                            IsSACommentActive = true;
                                            wasSAWritten = true;
                                        }
                                    }
                                    else
                                    {
                                        comment = getComment(line, commentSlashAsterisk, "");
                                        noOfComments++;
                                        WriteInFile(noOfComments, comment);
                                        IsSACommentActive = true;
                                    }
                                }
                            }
                        }

                        if (isDoubleSlashActive && !wasSAWritten) // if /* type comment wasn't written, the already set // type comment will be written
                        {
                            noOfComments++;                            
                            WriteInFile(noOfComments, finalComment);
                        }

                        // ---
                        // HTML COMMENT SEARCH
                        // ---

                        htmlCheck = filename.Substring(filename.Length - 2, 2);
                        if (htmlCheck == "ml") // only files ending in ml(mark-up language) (e.g. .cshtml, .html, .xml) can have Mark-up language (<!-- -->) comments
                        {
                            if ((line.Contains(commentHTML) || IsHTMLCommentActive) && !IsSACommentActive)
                            {
                                if (IsHTMLCommentActive) // checks if the HTML comment is ongoing
                                {
                                    if (line.Contains(endCommentHTML)) // checks if it ends on this line
                                    {
                                        comment = getComment(line, "", endCommentHTML);
                                        WriteInFile(-1, comment);
                                        IsSACommentActive = false;
                                    }
                                    else
                                    {
                                        comment = line; // if the whole line is a comment
                                        WriteInFile(-1, comment);
                                    }

                                }
                                else
                                {
                                    if (line.Contains(endCommentHTML)) // if it starts and ends on this line
                                    {
                                        comment = getComment(line, commentHTML, endCommentHTML);
                                        noOfComments++;
                                        WriteInFile(noOfComments, comment);
                                        IsSACommentActive = false;


                                    }
                                    else // if it only starts on this line
                                    {
                                        comment = getComment(line, commentHTML, "");
                                        noOfComments++;
                                        WriteInFile(noOfComments, comment);
                                        IsSACommentActive = true;
                                    }
                                }
                            }
                        }
                        
                    }
                    else // line doesn't contain any comments
                    {
                        stringCount = line.Count(x => x == '"'); 
                        if (stringCount % 2 == 1)   // checking if line starts a string 
                        {
                            isStringActive = true;
                        }
                        else isStringActive = false;
                    }
                } // END OF LINE LOOP   
            }   // end of file
            label2.ForeColor = Color.LimeGreen;
            label2.Text = "Done!";
        }

        private bool isInString(string line, string commentStart) // function checking if the sent comment start is within a string
        {
            string lineBeforeComment = line.Substring(0, line.IndexOf(commentStart));
            int stringCount = 0;
            stringCount = lineBeforeComment.Count(x => x == '"');
            if (stringCount % 2 == 0) return false;
            else return true;

        }

        private string getComment(string line, string commentStart, string commentEnd)
        {
            int commentStartIndex;
            if (commentStart == "") // if null is sent, this is an ongoing comment - index set at 0
            {
                commentStartIndex = 0;
            }
            else                    //otherwise, index is set at the start of comment
            {
                commentStartIndex = line.IndexOf(commentStart);
            }
            line = line.Remove(0, commentStartIndex);   // unnecesary part removed 
            commentStartIndex = line.IndexOf(commentStart); // start index rewritten with renowned line
            int commentEndIndex;
            
            if (commentEnd == endCommentSA || commentEnd==endCommentHTML) // if the comment end is sent, its character count is added
            {
                commentEndIndex = line.IndexOf(commentEnd)+ commentEnd.Length;
            }
            else // if null is sent, the comment lasts for the whole line - index is set at the length of line
            {
                commentEndIndex = line.Length;
            }
            string comment = line.Substring(commentStartIndex, commentEndIndex); // comment is set

            return comment; // comment is returned
        }

        private void WriteInFile(int index, string line)
        {
            using (StreamWriter file =
                    new StreamWriter(commentFilePath, true))
            {
                if (index == -1) // if the comment is ongoing - no index needed
                {
                    file.WriteLine(line);
                    file.Close();
                }
                else
                {
                    file.WriteLine(index + ". " + line); // if the comment starts - index is written along with the comment
                    file.Close();
                }

            }
        }
    }
}
