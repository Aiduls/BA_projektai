﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace WindowsFormsApp1
{
    public partial class CommentFinder : Form
    {
        public CommentFinder()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            string FolderPath = textBox1.Text; // Variable with the path to folder is set
            // C:\Users\Aidas\Desktop\Mokslai\IT\ReadmeBA-master\ReadmeBA-master\ReadmeBA

            string commentFilePath = FolderPath + "\\comments.txt";
            File.Delete(commentFilePath); // deletes the previous file if such was created earlier
            string[] fileNames = Directory.GetFiles(FolderPath, "*", SearchOption.AllDirectories); // list of all files within the folder and its subfolders is set
            GettingComments(fileNames, FolderPath, commentFilePath);

        }

        private void GettingComments(string[] fileNames, string folderPath, string commentFilePath)
        {
            string commentDoubleSlash = "//"; // types of comments 
            string commentTripleSlash = "///";
            string commentSlashAsterisk = "/*"; bool IsSACommentActive = false; // SA - Slash Asterisk comment
            string commentHTML = "<!--"; bool IsHTMLCommentActive = false;
            string endCommentSA = "*/";
            string endCommentHTML = "-->";

            string comment;
            int noOfComments = 0;
            string filename;

            for (int i = 0; i < fileNames.Length; i++)  // STARTS OF FILE -- a loop going through each file
            {
                filename = Path.GetFileName(fileNames[i]);
                noOfComments = 0;

                using (StreamWriter file =
                    new StreamWriter(commentFilePath, true))
                {
                    file.WriteLine("=========== " + filename + " ===========",true);
                    file.Close();
                }
                

                string fileName = fileNames[i];     // file path+name is set
                //string fileText;
                label2.Text = ""; // FOR TESTING PURPOSES

                string[] lines = File.ReadAllLines(fileName);

                foreach (string line in lines) // START OF LINE -- checking every line
                {
                    // If statements check if line contains a start of a comment or a part of a comment
                    if ((line.Contains(commentDoubleSlash) || line.Contains(commentTripleSlash)) && !IsSACommentActive && !IsHTMLCommentActive)
                    {
                        comment = line.Remove(0, 0);
                        comment = line.Substring(line.IndexOf(commentDoubleSlash)); // Comment is set as variable
                        noOfComments++;                                             // index is increased
                        WriteInFile(noOfComments, comment, commentFilePath);        // comment line is written into file
                    }
                    if ((line.Contains(commentSlashAsterisk) || IsSACommentActive) && !IsHTMLCommentActive )
                    {
                        if (IsSACommentActive)
                        {
                            if (line.Contains(endCommentSA)) // secondary if statements further check if the comment ends on this line or is ongoing througout this line
                            {
                                comment = line.Substring(0, line.IndexOf(endCommentSA)+2);
                                IsSACommentActive = false;
                                WriteInFile(-1, comment, commentFilePath);
                            }
                            else
                            {
                                comment = line;
                                WriteInFile(-1, comment, commentFilePath);
                            }
                            
                        }
                        else
                        {
                            if (line.Contains(endCommentSA))
                            {
                                comment = line.Substring(0, line.IndexOf(endCommentSA) + 2);
                                noOfComments++;
                                IsSACommentActive = false;
                                WriteInFile(noOfComments, comment, commentFilePath);
                            }
                            else
                            {
                                comment = line.Substring(line.IndexOf(commentSlashAsterisk));
                                noOfComments++;
                                WriteInFile(noOfComments, comment, commentFilePath);
                                IsSACommentActive = true;   // following lines are SA comments until boolean is set to false
                            }   
                        }
                    }
                    if ((line.Contains(commentHTML) || IsHTMLCommentActive) && !IsSACommentActive)
                    {
                        if (IsHTMLCommentActive)
                        {
                            if (line.Contains(endCommentHTML)) // secondary if statements further check if the comment ends on this line or is ongoing througout this line
                            {
                                comment = line.Substring(0, line.IndexOf(endCommentHTML)+3);
                                IsHTMLCommentActive = false;
                                WriteInFile(-1, comment, commentFilePath);
                            }
                            else
                            {
                                comment = line;
                                WriteInFile(-1, comment, commentFilePath);
                            }

                        }
                        else
                        {
                            if (line.Contains(endCommentHTML))
                            {
                                comment = line.Remove(0, line.IndexOf(commentHTML));
                                MessageBox.Show(comment);
                                comment = comment.Substring(comment.IndexOf(commentHTML), comment.IndexOf(endCommentHTML)+3);
                                MessageBox.Show("\n"+comment + " " + comment.IndexOf(commentHTML) + " " + line.IndexOf(endCommentHTML));
                                noOfComments++;
                                IsHTMLCommentActive = false;
                                WriteInFile(noOfComments, comment, commentFilePath);
                            }
                            else
                            {
                                comment = line.Substring(line.IndexOf(commentHTML));
                                noOfComments++;
                                WriteInFile(noOfComments, comment, commentFilePath);
                                IsHTMLCommentActive = true;   // following lines are HTML comments until boolean is set to false
                            }
                        }
                    }
                } // END OF LINE LOOP   
            }   // end of file
        }

        private void WriteInFile(int index, string line, string commentFilePath)
        {
            using (StreamWriter file =
                    new StreamWriter(commentFilePath, true))
            {
                if (index == -1)
                {
                    file.WriteLine(line);
                    file.Close();
                }
                else
                {
                    file.WriteLine(index + ". " + line);
                    file.Close();
                }

            }
        }
    }
}
